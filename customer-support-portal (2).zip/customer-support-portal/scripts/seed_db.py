#!/usr/bin/env python3
import csv, os
from pathlib import Path

path = Path('data/seed/customers.csv')
print('Would load', path, 'into DB via DATABASE_URL env.')
