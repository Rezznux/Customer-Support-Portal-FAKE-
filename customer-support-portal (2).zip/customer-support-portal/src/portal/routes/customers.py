from fastapi import APIRouter
router = APIRouter(prefix="/customers", tags=["customers"])
# (routes would go here)
